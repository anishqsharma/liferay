package Sample2Sahaj.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

/**
 * @author User
 */
@Controller
@RequestMapping("VIEW")
public class UserController {
	
	@RenderMapping
	public String prepareView()
	{
		return "user";
	}
}